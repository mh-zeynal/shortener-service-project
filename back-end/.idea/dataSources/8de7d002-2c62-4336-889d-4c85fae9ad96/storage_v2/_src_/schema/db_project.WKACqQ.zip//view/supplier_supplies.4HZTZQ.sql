create view supplier_supplies as
select `db_project`.`supplies`.`spare_id`       AS `spare_id`,
       `db_project`.`suppliers`.`supplier_id`   AS `supplier_id`,
       `db_project`.`suppliers`.`supplier_name` AS `supplier_name`,
       `db_project`.`suppliers`.`manager_name`  AS `manager_name`,
       `db_project`.`suppliers`.`start_date`    AS `start_date`,
       `db_project`.`suppliers`.`exp_date`      AS `exp_date`,
       `db_project`.`suppliers`.`address`       AS `address`,
       `db_project`.`spare_parts`.`in_stock`    AS `in_stock`,
       `db_project`.`spare_parts`.`price`       AS `price`,
       `db_project`.`spare_parts`.`name`        AS `name`
from ((`db_project`.`suppliers` join `db_project`.`supplies` on ((`db_project`.`suppliers`.`supplier_id` =
                                                                  `db_project`.`supplies`.`supplier_id`)))
         join `db_project`.`spare_parts`
              on ((`db_project`.`supplies`.`spare_id` = `db_project`.`spare_parts`.`spare_id`)));

