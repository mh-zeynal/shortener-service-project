create view customer_orders as
select `s`.`order_id`                            AS `order_id`,
       `s`.`national_number`                     AS `national_number`,
       `s`.`phone_number`                        AS `phone_number`,
       `s`.`first_name`                          AS `first_name`,
       `s`.`last_name`                           AS `last_name`,
       `s`.`customer_id`                         AS `customer_id`,
       `db_project`.`order_reports`.`order_type` AS `order_type`,
       `db_project`.`order_reports`.`product_id` AS `product_id`,
       `db_project`.`order_reports`.`date`       AS `date`
from ((select `db_project`.`customers`.`national_number` AS `national_number`,
              `db_project`.`customers`.`phone_number`    AS `phone_number`,
              `db_project`.`customers`.`first_name`      AS `first_name`,
              `db_project`.`customers`.`last_name`       AS `last_name`,
              `db_project`.`orders`.`order_id`           AS `order_id`,
              `db_project`.`orders`.`customer_id`        AS `customer_id`
       from (`db_project`.`customers`
                join `db_project`.`orders`
                     on ((`db_project`.`customers`.`national_number` = `db_project`.`orders`.`customer_id`)))) `s`
         join `db_project`.`order_reports` on ((`s`.`order_id` = `db_project`.`order_reports`.`order_id`)));

