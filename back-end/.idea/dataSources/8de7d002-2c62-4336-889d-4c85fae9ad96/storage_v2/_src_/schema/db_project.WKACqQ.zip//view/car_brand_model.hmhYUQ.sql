create view car_brand_model as
select `s`.`VIN` AS `VIN`, `s`.`brand` AS `brand`, `t`.`model` AS `model`
from (`db_project`.`cars` `s`
         join `db_project`.`car_models` `t` on ((`s`.`VIN` = `t`.`VIN`)));

