create definer = root@localhost trigger car_order_duplicate_trigger
    before update
    on cars
    for each row
begin
        if (exists(
            select * from cars as C
            where C.VIN=NEW.VIN and C.is_sold=FALSE)) then
            set New.VIN=New.VIN;
        else
            set NEW.VIN=null;
        end if;
    end;

