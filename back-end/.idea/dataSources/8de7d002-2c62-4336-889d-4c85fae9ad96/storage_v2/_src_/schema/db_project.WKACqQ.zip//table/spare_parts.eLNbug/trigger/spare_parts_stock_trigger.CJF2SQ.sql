create definer = root@localhost trigger spare_parts_stock_trigger
    before update
    on spare_parts
    for each row
begin
        if (NEW.in_stock <= 0) then
            set NEW.in_stock = OLD.in_stock;
        else
            set NEW.in_stock = NEW.in_stock;
        end if;
    end;

